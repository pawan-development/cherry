# VerticalSliderShowCase

A responsive vertical fullscreen slider that moves its sections in opposite directions. By using jQuery, CSS Transitions and media queries to make the layout adaptive.

[Demo]()

[Download]()

Licensed under Apache-2.0 License