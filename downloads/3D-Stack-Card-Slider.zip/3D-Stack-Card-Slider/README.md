# stack-slider
# Author: Dipesh thapa
# Author Site: http://dpes.com.np/

An experimental image slider that flips through images in 3D. Four stacks resemble image piles where images will be lifted off from and rotated to the front for viewing.

Watch Demo at http://dpes.com.np/demo.html
